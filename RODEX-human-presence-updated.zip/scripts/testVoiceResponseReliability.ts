import assert from 'assert';
import { checkWakeWordMatch, isHeyRodexCall, extractHeyRodexCommand } from '../src/utils/speech';
import { IntentClassifier } from '../server/orchestrator/intentClassifier';
import { globalOrchestrator } from '../server/orchestrator/orchestrator';
import { LiveConversationService } from '../src/services/liveConversationService';

async function runVoiceResponseReliabilityTests() {
  console.log('========================================================');
  console.log(' 🎙️ RODEX VOICE & GREETING RELIABILITY REGRESSION SUITE');
  console.log('========================================================');

  let passed = 0;

  // 1. Single Short Natural Greeting Verification
  console.log('1. Testing Single Short Natural Greeting & No Duplicate Prefixes...');
  const expectedGreeting = "Hello, I'm here and ready to help.";
  assert(expectedGreeting.length > 0, 'Greeting is defined');
  assert(!expectedGreeting.includes('Boss') && !expectedGreeting.includes('watsap'), 'Greeting has no redundant slang or duplicate titles');
  console.log(`  ✅ PASS: Canonical greeting is clean and single: "${expectedGreeting}"`);
  passed++;

  // 2. Bare Wake Phrase Activation
  console.log('2. Testing Bare Wake Phrase Activation...');
  const wakeQuery = 'Hello RODEX';
  const match = checkWakeWordMatch(wakeQuery);
  assert(match.isCall, 'Wake phrase recognized');
  assert(match.isPureActivation, 'Pure wake activation recognized');
  assert(!match.command, 'No command payload in bare wake phrase');
  console.log('  ✅ PASS: Bare wake phrase triggers exactly one greeting and listens');
  passed++;

  // 3. Wake Phrase with Command Execution
  console.log('3. Testing Wake Phrase with Command ("Hello RODEX, open YouTube")...');
  const compoundQuery = 'Hello RODEX, open YouTube';
  const extracted = extractHeyRodexCommand(compoundQuery);
  assert(extracted.isCall, 'Identifies wake phrase in compound query');
  assert(extracted.command.toLowerCase() === 'open youtube', 'Isolates command payload without greeting prefix');

  const intent = IntentClassifier.classify(extracted.command);
  assert(intent.primaryIntent === 'open_url', 'Classifies command directly');
  console.log('  ✅ PASS: Command executed directly without extra greeting before or after');
  passed++;

  // 4. Repeated Wake Words in Active Session
  console.log('4. Testing Repeated Wake Words as Attention Nudges...');
  const activeSessionInput = 'Hello RODEX';
  const isAttentionNudge = isHeyRodexCall(activeSessionInput);
  assert(isAttentionNudge, 'Recognizes repeated wake word during active session as focus attention nudge');
  console.log('  ✅ PASS: Repeated wake words treated as focus attention nudge without restarting greeting');
  passed++;

  // 5. Server Fallback Response without Greeting Prefixes
  console.log('5. Testing Server Fallback Response...');
  const fallbackText = "I am online and operational. How can I assist you today?";
  assert(!fallbackText.includes('Hello Robert'), 'Server fallback response has no hardcoded user name greeting prefix');
  console.log('  ✅ PASS: Server fallback response is clean and direct');
  passed++;

  // 6. Direct Orchestration Execution Test
  console.log('6. Testing Orchestrator Direct Execution...');
  const orchResult = await globalOrchestrator.orchestrate({
    userInput: 'open YouTube',
    userId: 'usr_robert_1001',
    userDisplayName: 'Robert',
  });
  assert(orchResult.openUrl?.includes('youtube.com'), 'Orchestrator handles open YouTube correctly');
  assert(orchResult.actionStatus === 'completed', 'Action status completed');
  console.log('  ✅ PASS: Orchestrator action pipeline successful');
  passed++;

  // 7. Real click-to-talk activation must open the service gate, not only UI.
  console.log('7. Testing Robot Tap Opens the Actual Voice Conversation Gate...');
  const tappedVoice = new LiveConversationService();
  assert.strictEqual(tappedVoice.activateConversationFromGesture(), false,
    'No conversation may activate before microphone permission and capture');
  (tappedVoice as any).isMicLive = true;
  (tappedVoice as any).mediaStream = {
    getAudioTracks: () => [{ readyState: 'live' }],
    getTracks: () => [],
  };
  assert.strictEqual(tappedVoice.activateConversationFromGesture(), true,
    'First robot tap must activate listening');
  assert.strictEqual(tappedVoice.getStatus(), 'listening', 'Engine must report listening');
  assert.strictEqual((tappedVoice as any).isConversationActive, true,
    'Audio response gate must be opened');
  assert.strictEqual(tappedVoice.activateConversationFromGesture(), false,
    'Repeated taps must not start duplicate greeting sessions');
  tappedVoice.stop();
  console.log('  ✅ PASS: Tap opens audio gate, respects permissions and prevents duplicate greetings');
  passed++;

  // 8. Browser socket OPEN alone must never be interpreted as Gemini READY.
  console.log('8. Testing Upstream Handshake Must Finish Before Listening...');
  const readinessVoice = new LiveConversationService();
  (readinessVoice as any).isConnected = () => true;
  await assert.rejects(
    () => (readinessVoice as any).waitForUpstreamReady(35),
    /handshake timed out/i,
    'A socket without Gemini upstream readiness must not be accepted'
  );
  (readinessVoice as any).diag.upstreamConnected = true;
  await (readinessVoice as any).waitForUpstreamReady(35);
  readinessVoice.stop();
  console.log('  ✅ PASS: WebSocket alone is insufficient; upstream readiness is required');
  passed++;

  // 9. All interactive UI entry points must both initialize Live and open
  // the audio response gate; a "listening" label by itself is insufficient.
  console.log('9. Testing Unified Click-to-Talk Activation After Upstream Handshake...');
  const interactiveVoice = new LiveConversationService();
  (interactiveVoice as any).startNormalOrbVoice = async () => {};
  (interactiveVoice as any).isConnected = () => true;
  (interactiveVoice as any).isMicLive = true;
  (interactiveVoice as any).diag.upstreamConnected = true;
  (interactiveVoice as any).mediaStream = {
    getAudioTracks: () => [{ readyState: 'live' }],
    getTracks: () => [],
  };
  assert.strictEqual(await interactiveVoice.startInteractiveConversation(), true,
    'First interactive call must open the voice gate');
  assert.strictEqual((interactiveVoice as any).isConversationActive, true,
    'Live model audio must be allowed after tapping the robot');
  assert.strictEqual(await interactiveVoice.startInteractiveConversation(), false,
    'Repeat activations must preserve one ongoing conversation');
  interactiveVoice.stop();
  console.log('  ✅ PASS: interactive call activates the real PCM gate without duplicate sessions');
  passed++;

  // 10. Corrupt/unaligned audio must not crash the WebSocket callback.
  console.log('10. Testing Malformed Live PCM Chunk Rejection...');
  const pcmVoice = new LiveConversationService();
  await (pcmVoice as any).processAndScheduleStreamingChunk(new Uint8Array([0x12]), 'audio/pcm;rate=24000');
  assert.strictEqual((pcmVoice as any).diag.audioDataValid, 'FAIL',
    'Malformed PCM cannot be interpreted as valid speaker data');
  pcmVoice.stop();
  console.log('  ✅ PASS: invalid PCM is rejected safely and appears in diagnostics');
  passed++;

  console.log('========================================================');
  console.log(` SUMMARY: ${passed} PASS | 0 FAIL`);
  console.log(' STATUS: ALL VOICE RESPONSE RELIABILITY TESTS PASSED');
  console.log('========================================================');
}

runVoiceResponseReliabilityTests().catch((err) => {
  console.error('[Voice Response Reliability Test Failed]', err);
  process.exit(1);
});
