import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion } from 'motion/react';
import {
  Mic,
  MicOff,
  Settings,
  Volume2,
  VolumeX,
  Sparkles,
  MessageSquare,
  AlertCircle,
  Radio,
  UserCheck,
  Phone,
  PhoneOff,
  Zap,
  Globe,
  ExternalLink,
  Music2,
  Maximize2,
  Minimize2,
  Shield,
  RefreshCw,
  Award,
  Play,
  Youtube,
  X,
  Brain,
  Cpu,
  Film,
  Video as VideoIcon,
  Stethoscope,
  Mail,
  Menu,
  UserRound,
  Plus,
  Keyboard,
  ArrowUp,
  PanelsTopLeft,
  Grid2X2,
  Home,
} from 'lucide-react';
import { HumanoidPresence } from './components/HumanoidPresence';
import { RODEXWorkspace } from './components/RODEXWorkspace';
import { RODEXFloatingCompanion } from './components/RODEXFloatingCompanion';
import { RodexSpeechWave } from './components/RodexSpeechWave';
import './components/RodexImmersive.css';
import { ActionBar } from './components/ActionBar';
import { MoreMenu } from './components/MoreMenu';
import { ChatSheet } from './components/ChatSheet';
import { SettingsModal } from './components/SettingsModal';
import { ModesModal } from './components/ModesModal';
import { VoiceProfileModal } from './components/VoiceProfileModal';
import { WebVerificationModal } from './components/WebVerificationModal';
import { SpotifyPlayerModal } from './components/SpotifyPlayerModal';
import { WebMediaHubModal } from './components/WebMediaHubModal';
import { SecurityCenterModal } from './components/SecurityCenterModal';
import { UpdateCenterModal } from './components/UpdateCenterModal';
import { AuthModal } from './components/AuthModal';
import { UserProfileModal } from './components/UserProfileModal';
import { MemoryPersonalizationModal } from './components/MemoryPersonalizationModal';
import { CapabilityHubModal } from './components/CapabilityHubModal';
import { MediaStudioModal } from './components/MediaStudioModal';
import { RodexDoctorModal } from './components/RodexDoctorModal';
import { GmailHubModal } from './components/GmailHubModal';
import { ScheduleModal } from './components/ScheduleModal';
import { FirebaseAuthButton } from './components/FirebaseAuthButton';
import { SpotifyMiniBar } from './components/SpotifyMiniBar';
import { AndroidFrame } from './components/AndroidFrame';
import { getCachedGmailAccessToken } from './services/firebase';
import { globalAuthClient, AuthenticatedUser } from './services/authClient';
import { TaskCard } from './components/TaskCard';
import { VoiceDiagnosticPanel } from './components/VoiceDiagnosticPanel';
import { globalTaskEngine } from './services/TaskEngine';
import {
  AssistantState,
  ChatMessage,
  AppMode,
  VoiceSettings,
  ThemeAccent,
  VoiceProfile,
  WebSource,
  SpotifyTrackInfo,
  SpotifyDevice,
  ChatSession,
  AgentTask,
} from './types';
import {
  rodexSynth,
  AudioMeter,
  isHeyRodexCall,
  containsHeyRodexWakeWord,
  extractHeyRodexCommand,
  checkWakeWordMatch,
  playToneChime,
  isConversationExit,
  normalizeForWakeWord,
} from './utils/speech';
import { triggerHaptic, setHapticsEnabled, triggerSubtlePulse } from './utils/haptics';
import { rodexBeatbox } from './utils/beatbox';
import { globalSpeechManager } from './utils/speechManager';
import { globalVoiceManager } from './utils/voiceLifecycleManager';
import { globalVoiceTransitionEngine } from './utils/voiceTransitionEngine';
import { globalLiveConversationService } from './services/liveConversationService';
import {
  loadActiveSession,
  saveActiveSession,
  loadAllSessions,
  createNewSession,
  deleteSessionFromHistory,
} from './utils/sessionStorage';
import { getActiveOrbTheme } from './utils/orbTheme';

// Defer voice-engine cleanup by one microtask so React StrictMode's
// development-only setup/cleanup/setup cycle doesn't kill and restart the mic
// permission request before the second setup can reuse the singleton.
let liveVoiceMountGeneration = 0;

const createId = (prefix = 'msg') =>
  typeof crypto !== 'undefined' && crypto.randomUUID
    ? crypto.randomUUID()
    : `${prefix}-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;

export default function App() {
  // Core Assistant States
  const [state, setState] = useState<AssistantState>('idle');
  const [activeMode, setActiveMode] = useState<AppMode>('home');
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isWorkspaceOpen, setIsWorkspaceOpen] = useState(false);
  const [quickPrompt, setQuickPrompt] = useState('');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isVoiceProfileOpen, setIsVoiceProfileOpen] = useState(false);
  const [isWebVerifyOpen, setIsWebVerifyOpen] = useState(false);
  const [isSpotifyOpen, setIsSpotifyOpen] = useState(false);
  const [isMediaHubOpen, setIsMediaHubOpen] = useState(false);
  const [isSecurityOpen, setIsSecurityOpen] = useState(false);
  const [isUpdateOpen, setIsUpdateOpen] = useState(false);
  const [isUserProfileOpen, setIsUserProfileOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalTab, setAuthModalTab] = useState<'signin' | 'register' | 'recover'>('signin');
  const [currentUser, setCurrentUser] = useState<AuthenticatedUser | null>(() => globalAuthClient.getCurrentUser());
  const [isMemoryOpen, setIsMemoryOpen] = useState(false);
  const [isCapabilityOpen, setIsCapabilityOpen] = useState(false);
  const [isMediaStudioOpen, setIsMediaStudioOpen] = useState(false);
  const [isDoctorOpen, setIsDoctorOpen] = useState(false);
  const [isGmailOpen, setIsGmailOpen] = useState(false);
  const [isScheduleOpen, setIsScheduleOpen] = useState(false);
  const [isMoreMenuOpen, setIsMoreMenuOpen] = useState(false);
  const [mediaStudioTab, setMediaStudioTab] = useState<'video' | 'image' | 'maps' | 'search' | 'gallery'>('video');

  // Live Chat Sessions & Persistence
  const [activeSession, setActiveSession] = useState<ChatSession>(() => loadActiveSession());
  const [allSessions, setAllSessions] = useState<ChatSession[]>(() => loadAllSessions());

  // Spotify Playback on PC
  const [spotifyPlayback, setSpotifyPlayback] = useState<SpotifyTrackInfo | null>(null);
  const [spotifyDevice, setSpotifyDevice] = useState<SpotifyDevice | null>(null);

  // Poll or refresh Spotify status
  const refreshSpotifyStatus = useCallback(async () => {
    try {
      const res = await fetch('/api/spotify/status');
      if (res.ok) {
        const data = await res.json();
        setSpotifyPlayback(data.playback || null);
        setSpotifyDevice(data.device || null);
      }
    } catch (_) {}
  }, []);

  useEffect(() => {
    refreshSpotifyStatus();
    const interval = setInterval(refreshSpotifyStatus, 6000);
    return () => clearInterval(interval);
  }, [refreshSpotifyStatus]);

  // Multi-user authentication synchronization
  useEffect(() => {
    globalAuthClient.getMe().then((user) => {
      if (user) {
        setCurrentUser(user);
        setVoiceProfile((prev) => ({
          ...prev,
          speakerName: user.displayName || user.profile?.preferredName || 'Robert',
        }));
      }
    });

    const unsubscribe = globalAuthClient.subscribe((user) => {
      setCurrentUser(user);
      if (user) {
        setVoiceProfile((prev) => ({
          ...prev,
          speakerName: user.displayName || user.profile?.preferredName || 'Robert',
        }));
      }
    });

    return () => unsubscribe();
  }, []);

  // Real-time Two-Way Live Conversation State
  const [isLiveConversation, setIsLiveConversation] = useState(false);
  const isLiveConversationRef = useRef(false);
  const consecutiveSilenceCountRef = useRef(0);
  const silenceTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Active Agent Task State (Proactive, Multi-Step & Real-World Agent Jobs)
  const [activeTask, setActiveTask] = useState<AgentTask | null>(null);

  useEffect(() => {
    const unsub = globalTaskEngine.subscribe((task) => {
      setActiveTask(task);
    });
    return unsub;
  }, []);

  useEffect(() => {
    if (currentUser?.uid) {
      globalTaskEngine.setUserId(currentUser.uid);
    }
  }, [currentUser]);

  // Voice Profile / Speaker Recognition State
  const [voiceProfile, setVoiceProfile] = useState<VoiceProfile>({
    speakerName: 'User',
    isRecognized: true,
    confidence: 99.4,
    pitchHz: 124,
    voiceprintStatus: 'calibrated',
    wakeWord: 'Hey RODEX',
  });

  // Audio and Speech State
  const [audioLevel, setAudioLevel] = useState(0);
  const lastAudioPaintRef = useRef(0);
  const lastHapticRef = useRef(0);
  // Throttle UI renders, not the audio capture/playback pipeline.
  const renderLiveAudio = useCallback((inputLevel: number, outputLevel: number) => {
    // A user's microphone must never animate RODEX's own mouth.
    // In SPEAKING the Gemini output analyser is authoritative; in LISTENING,
    // input amplitude is free to drive attention without opening the jaw.
    const sample = stateRef.current === 'speaking' ? outputLevel : inputLevel;
    const level = Math.max(0, Math.min(1, Number.isFinite(sample) ? sample : 0));
    const now = performance.now();
    if (now - lastAudioPaintRef.current >= 45 || level === 0) {
      lastAudioPaintRef.current = now;
      setAudioLevel(current => Math.abs(current - level) > .035 ? level : current);
    }
    if (level > .35 && now - lastHapticRef.current > 350) {
      lastHapticRef.current = now;
      triggerSubtlePulse(8);
    }
  }, []);
  const [pitchHz, setPitchHz] = useState<number>(124);
  const [transcript, setTranscript] = useState('');
  const [lastResponse, setLastResponse] = useState<string>(
    'Greetings. I am RODEX. Say "Hello RODEX" to speak.'
  );
  const [isMuted, setIsMuted] = useState(false);
  const [micPermissionGranted, setMicPermissionGranted] = useState(false);
  const [showPermDialog, setShowPermDialog] = useState(false);

  // Core Developer Voice Engine Diagnostics
  const [diagSupport, setDiagSupport] = useState(() => {
    if (typeof window === 'undefined') return 'Checking...';
    return (window as any).SpeechRecognition ? 'Standard API' : (window as any).webkitSpeechRecognition ? 'Webkit API' : 'Not Supported';
  });
  const [diagCreated, setDiagCreated] = useState(false);
  const [diagPermission, setDiagPermission] = useState('Checking...');
  const [diagRunning, setDiagRunning] = useState('Inactive');
  const [diagLastEvent, setDiagLastEvent] = useState('None');
  const [diagLastError, setDiagLastError] = useState('None');
  const [diagLastTranscript, setDiagLastTranscript] = useState('');
  const [diagWakeMatched, setDiagWakeMatched] = useState(false);
  const [diagCurrentState, setDiagCurrentState] = useState('idle');
  const [showDiagPanel, setShowDiagPanel] = useState(false);

  // Live Pipeline Trace States for Voice Diagnostic Panel
  const [aiRequestState, setAiRequestState] = useState<string>('idle');
  const [aiResponseState, setAiResponseState] = useState<string>('idle');
  const [ttsState, setTtsState] = useState<string>('idle');
  const [capturedCommand, setCapturedCommand] = useState<string>('');

  useEffect(() => {
    setDiagCurrentState(state);
  }, [state]);

  // Settings
  const [voiceSettings, setVoiceSettings] = useState<VoiceSettings>({
    voiceURI: '',
    rate: 1.08,
    pitch: 1.0,
    volume: 1.0,
    autoSpeak: true,
    wakeWordEnabled: true,
    audioSens: 3,
    webSearchEnabled: true,
    hapticFeedbackEnabled: true,
  });
  const voiceSettingsRef = useRef(voiceSettings);
  useEffect(() => {
    voiceSettingsRef.current = voiceSettings;
  }, [voiceSettings]);
  const [themeAccent, setThemeAccent] = useState<ThemeAccent>(() => {
    return (localStorage.getItem('rodex_theme_accent') as ThemeAccent) || 'auto';
  });

  const handleUpdateTheme = (theme: ThemeAccent) => {
    setThemeAccent(theme);
    localStorage.setItem('rodex_theme_accent', theme);
  };

  // Synchronize Haptic Vibration State with User Preferences
  useEffect(() => {
    setHapticsEnabled(voiceSettings.hapticFeedbackEnabled !== false);
  }, [voiceSettings.hapticFeedbackEnabled]);

  // Dynamically resolved theme-aware orb glow palette (Gold for thinking, Cyan for idle, Ruby for live calls)
  const currentOrbTheme = React.useMemo(() => {
    return getActiveOrbTheme({
      state,
      isLive: isLiveConversation,
      activeMode,
      themeAccent,
    });
  }, [state, isLiveConversation, activeMode, themeAccent]);

  // Dynamic High-Velocity Neural Capacity Tracker (operating at millions of operations per second)
  const [neuralOps, setNeuralOps] = useState('784.6M');
  const [thinkingOps, setThinkingOps] = useState('860.2M');

  useEffect(() => {
    const interval = setInterval(() => {
      if (state === 'thinking') {
        const ops = (820 + Math.random() * 160).toFixed(1);
        setThinkingOps(`${ops}M`);
        setNeuralOps(`${ops}M`);
      } else if (state === 'speaking' || state === 'listening') {
        const ops = (680 + Math.random() * 120).toFixed(1);
        setNeuralOps(`${ops}M`);
      } else {
        const ops = (560 + Math.random() * 80).toFixed(1);
        setNeuralOps(`${ops}M`);
      }
    }, 120);
    return () => clearInterval(interval);
  }, [state]);

  // Synchronized Heartbeat Tactile Pulsing during THINKING / PROCESSING states
  useEffect(() => {
    let thinkingHeartbeatTimer: NodeJS.Timeout | null = null;
    
    if (state === 'thinking' || state === 'processing') {
      thinkingHeartbeatTimer = setInterval(() => {
        // Double heartbeat haptic pulse
        triggerSubtlePulse(10);
        setTimeout(() => {
          triggerSubtlePulse(10);
        }, 140);
      }, 1000);
    }

    return () => {
      if (thinkingHeartbeatTimer) {
        clearInterval(thinkingHeartbeatTimer);
      }
    };
  }, [state]);

  const stateRef = useRef(state);
  useEffect(() => {
    stateRef.current = state;
  }, [state]);

  // Pending Request AbortController & Deduplication Ref
  const activeAbortControllerRef = useRef<AbortController | null>(null);
  const lastSentQueryRef = useRef<{ text: string; time: number }>({ text: '', time: 0 });

  // Screen-Adaptive Responsive Orb Sizing for Full-Screen & Multi-Device Previews
  const [orbSize, setOrbSize] = useState(280);
  useEffect(() => {
    const handleResize = () => {
      const w = window.innerWidth;
      const h = window.innerHeight;
      if (w >= 1024 && h >= 800) {
        setOrbSize(340);
      } else if (w >= 768 && h >= 680) {
        setOrbSize(300);
      } else if (h < 640) {
        setOrbSize(220);
      } else {
        setOrbSize(260);
      }
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // HTML5 Fullscreen State & Toggle
  const [isFullscreen, setIsFullscreen] = useState(false);

  useEffect(() => {
    const onFSChange = () => {
      setIsFullscreen(Boolean(document.fullscreenElement));
    };
    document.addEventListener('fullscreenchange', onFSChange);
    return () => document.removeEventListener('fullscreenchange', onFSChange);
  }, []);

  const toggleFullscreen = useCallback(() => {
    try {
      if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen().catch(() => {});
      } else {
        document.exitFullscreen().catch(() => {});
      }
    } catch (_) {}
  }, []);

  // Messages History & Web Grounding Sources
  const [messages, setMessages] = useState<ChatMessage[]>(() => activeSession.messages || []);
  const [lastSources, setLastSources] = useState<WebSource[]>([]);
  const [lastSearchQueries, setLastSearchQueries] = useState<string[]>([]);

  // Browser Navigation & Web-Opening Execution Feedback
  const [browserActionToast, setBrowserActionToast] = useState<{
    url: string;
    label: string;
    destinationType?: 'youtube' | 'google' | 'website';
    status: 'opened' | 'blocked';
    timestamp: number;
  } | null>(null);

  const handleOpenUrlInBrowser = useCallback(
    (url: string, label?: string, destinationType?: 'youtube' | 'google' | 'website') => {
      if (!url) return;
      const cleanUrl = url.trim();
      const siteLabel =
        label ||
        (cleanUrl.includes('youtube.com')
          ? 'YouTube'
          : cleanUrl.includes('google.com')
          ? 'Google'
          : 'External Website');

      try {
        // Avoid the noopener feature here because some browsers return null for it
        // even when a tab opens. Clear opener immediately after obtaining the window.
        const openedWindow = window.open(cleanUrl, '_blank');
        if (openedWindow) {
          try {
            openedWindow.opener = null;
          } catch {
            // Browser policy may restrict opener access; the navigation was still requested.
          }
        }
        const isBlocked = !openedWindow;

        setBrowserActionToast({
          url: cleanUrl,
          label: siteLabel,
          destinationType,
          status: isBlocked ? 'blocked' : 'opened',
          timestamp: Date.now(),
        });

        if (!isBlocked) {
          setTimeout(() => {
            setBrowserActionToast((prev) => (prev?.url === cleanUrl ? null : prev));
          }, 8000);
        }
      } catch (err) {
        console.warn('[RODEX Browser Open Error]', err);
        setBrowserActionToast({
          url: cleanUrl,
          label: siteLabel,
          destinationType,
          status: 'blocked',
          timestamp: Date.now(),
        });
      }
    },
    []
  );

  // Synchronize Active Session with Local Storage
  useEffect(() => {
    setActiveSession((prev) => {
      const updated: ChatSession = {
        ...prev,
        messages,
        lastActiveAt: new Date().toISOString(),
      };
      saveActiveSession(updated);
      return updated;
    });
    setAllSessions(loadAllSessions());
  }, [messages]);

  const handleSelectSession = (session: ChatSession) => {
    setActiveSession(session);
    setMessages(session.messages || []);
    saveActiveSession(session);
  };

  const handleNewSession = () => {
    const newSession = createNewSession();
    setActiveSession(newSession);
    setMessages(newSession.messages || []);
    setAllSessions(loadAllSessions());
  };

  const handleDeleteSession = (sessionId: string) => {
    const remaining = deleteSessionFromHistory(sessionId);
    setAllSessions(remaining);
    if (activeSession.id === sessionId) {
      if (remaining.length > 0) {
        handleSelectSession(remaining[0]);
      } else {
        handleNewSession();
      }
    }
  };

  // Refs for Speech Recognition and Audio Meter
  const recognitionRef = useRef<any>(null);
  const audioMeterRef = useRef<AudioMeter>(new AudioMeter());
  const animationFrameRef = useRef<number | null>(null);
  const bargeInAnimationFrameRef = useRef<number | null>(null);
  const lastCapturedRef = useRef<string>('');
  const liveSilenceTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const wakeWordTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const speakIntervalRef = useRef<NodeJS.Timeout | null>(null);
  
  // High-performance voice sentence queueing refs
  const speechQueueRef = useRef<string[]>([]);
  const isSpeechQueueRunningRef = useRef<boolean>(false);

  // High-resolution real-time developer metrics state
  const [perfMetrics, setPerfMetrics] = useState<any>(null);

  useEffect(() => {
    if (!showDiagPanel) return;
    const fetchPerf = async () => {
      try {
        const res = await fetch('/api/rodex/performance');
        if (res.ok) {
          const data = await res.json();
          setPerfMetrics(data);
        }
      } catch (_) {}
    };
    fetchPerf();
    const interval = setInterval(fetchPerf, 2000);
    return () => clearInterval(interval);
  }, [showDiagPanel]);

  const processSpeechQueue = useCallback(() => {
    if (speechQueueRef.current.length === 0) {
      isSpeechQueueRunningRef.current = false;
      return;
    }
    isSpeechQueueRunningRef.current = true;
    const nextSentence = speechQueueRef.current.shift()!;
    const hasMore = speechQueueRef.current.length > 0;
    speakResponse(
      nextSentence,
      () => {
        if (hasMore) {
          processSpeechQueue();
        } else {
          isSpeechQueueRunningRef.current = false;
        }
      },
      { isQueueInterim: hasMore }
    );
  }, []);

  // Auto-Probe Microphone Permission on Boot & Account Login without triggering intrusive prompt
  const probeMicPermission = useCallback(async (): Promise<boolean> => {
    console.info('[RODEX DIAGNOSTICS] MIC PERMISSION probe started');
    setDiagPermission('Probing...');
    try {
      if (navigator.permissions && navigator.permissions.query) {
        const permissionStatus = await navigator.permissions.query({ name: 'microphone' as PermissionName });
        console.info('[RODEX DIAGNOSTICS] MIC PERMISSION state:', permissionStatus.state);
        setDiagPermission(permissionStatus.state);
        if (permissionStatus.state === 'granted') {
          setMicPermissionGranted(true);
          globalSpeechManager.setMicPermission(true);
          return true;
        } else {
          setMicPermissionGranted(false);
          globalSpeechManager.setMicPermission(false);
          return false;
        }
      }
    } catch (e) {
      setDiagPermission('prompt');
      console.info('[RODEX DIAGNOSTICS] MIC PERMISSION query unavailable, will prompt on user click');
    }
    return false;
  }, []);

  useEffect(() => {
    probeMicPermission();
  }, [currentUser, probeMicPermission]);

  // Set up microphone permission listener
  useEffect(() => {
    console.info('[RODEX DIAGNOSTICS] VOICE INIT - System initializing...');
    if (navigator.permissions && navigator.permissions.query) {
      navigator.permissions
        .query({ name: 'microphone' as PermissionName })
        .then((permissionStatus) => {
          console.info('[RODEX DIAGNOSTICS] MIC PERMISSION initial state:', permissionStatus.state);
          setDiagPermission(permissionStatus.state);
          const isGranted = permissionStatus.state === 'granted';
          setMicPermissionGranted(isGranted);
          globalSpeechManager.setMicPermission(isGranted);

          permissionStatus.onchange = () => {
            console.info('[RODEX DIAGNOSTICS] MIC PERMISSION state changed to:', permissionStatus.state);
            setDiagPermission(permissionStatus.state);
            const granted = permissionStatus.state === 'granted';
            setMicPermissionGranted(granted);
            globalSpeechManager.setMicPermission(granted);
          };
        })
        .catch((e) => {
          setDiagPermission('prompt');
          console.info('[RODEX DIAGNOSTICS] MIC PERMISSION query failed or unsupported:', e);
        });
    }

    return () => {
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
      audioMeterRef.current.stop();
      rodexSynth.stop();
    };
  }, []);

  // Request Microphone Permission (Triggered upon user interaction with Orb or Mic button)
  const requestMicPermission = useCallback(async (): Promise<boolean> => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      // Release initial probe stream
      stream.getTracks().forEach((track) => track.stop());
      setMicPermissionGranted(true);
      globalSpeechManager.setMicPermission(true);
      setDiagPermission('granted');
      setShowPermDialog(false);
      return true;
    } catch (err) {
      console.warn('[RODEX Mic Perm Denied or Dismissed]', err);
      setMicPermissionGranted(false);
      globalSpeechManager.setMicPermission(false);
      setDiagPermission('denied');
      setShowPermDialog(false);
      return false;
    }
  }, []);

  // Audio meter loop for real-time orb reactivity and voice biometric tracking
  const startAudioMeterLoop = () => {
    const update = () => {
      const metrics = audioMeterRef.current.getVoiceMetrics();
      setAudioLevel(metrics.level * (voiceSettings.audioSens * 0.7));
      if (metrics.pitchHz > 0) {
        setPitchHz(metrics.pitchHz);
      }
      if (metrics.isSpeech) {
        setVoiceProfile((prev) => ({
          ...prev,
          pitchHz: metrics.pitchHz,
          confidence: Math.max(prev.confidence, metrics.confidence),
          voiceprintStatus: 'matched',
        }));
      }
      animationFrameRef.current = requestAnimationFrame(update);
    };
    update();
  };

  const stopAudioMeterLoop = () => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
    setAudioLevel(0);
    setPitchHz(124);
    audioMeterRef.current.stop();
  };

  // Speak AI text response using voice synthesis
  const speakResponse = useCallback(
    (text: string, onComplete?: () => void, options?: { isQueueInterim?: boolean }) => {
      if (isMuted || !voiceSettings.autoSpeak) {
        setState('idle');
        onComplete?.();
        return;
      }

      setState('speaking');

      // Browser speech synthesis does not expose a playable PCM stream.
      // Drive mouth shapes from actual word boundaries instead of a fabricated
      // sine-wave "audio meter". Gemini Live uses its real output analyser.
      if (speakIntervalRef.current) {
        clearTimeout(speakIntervalRef.current);
        speakIntervalRef.current = null;
      }
      setAudioLevel(0);

      if (bargeInAnimationFrameRef.current) {
        cancelAnimationFrame(bargeInAnimationFrameRef.current);
        bargeInAnimationFrameRef.current = null;
      }

      // Start monitoring for User Barge-in if Live Conversation Mode is active
      if (isLiveConversationRef.current) {
        audioMeterRef.current.start().then((started) => {
          if (!started) return;
          const speakStartTime = Date.now();

          const monitorInterruption = () => {
            if (stateRef.current !== 'speaking' || !isLiveConversationRef.current) {
              if (bargeInAnimationFrameRef.current) {
                cancelAnimationFrame(bargeInAnimationFrameRef.current);
                bargeInAnimationFrameRef.current = null;
              }
              return;
            }

            // Allow 800ms of speaking before permitting barge-in (prevents self-triggering on starts/chimes)
            if (Date.now() - speakStartTime > 800) {
              const metrics = audioMeterRef.current.getVoiceMetrics();
              if (metrics.isSpeech && metrics.level > 0.08) {
                console.info('[RODEX Barge-In] User interrupted speak stream:', metrics);
                
                // Immediately stop current speak playback
                rodexSynth.stop();
                
                // Play barge-in chime
                playToneChime('bargein');

                // Clean up the current VAD frame
                if (bargeInAnimationFrameRef.current) {
                  cancelAnimationFrame(bargeInAnimationFrameRef.current);
                  bargeInAnimationFrameRef.current = null;
                }
                audioMeterRef.current.stop();

                // Immediately switch to listening to capture the new statement
                startListening();
                return;
              }
            }

            bargeInAnimationFrameRef.current = requestAnimationFrame(monitorInterruption);
          };

          bargeInAnimationFrameRef.current = requestAnimationFrame(monitorInterruption);
        });
      }

      console.info('[RODEX DIAGNOSTICS] TTS START:', text);
      globalVoiceTransitionEngine.transitionProcessingToSpeaking({ source: 'speak_response_start' });
      globalSpeechManager.setSelfSpeaking(true);
      rodexSynth.speak(text, {
        voiceURI: voiceSettings.voiceURI,
        rate: voiceSettings.rate,
        pitch: voiceSettings.pitch,
        volume: voiceSettings.volume,
        onStart: () => {
          setState('speaking');
          setTtsState('speaking');
          setAudioLevel(.08);
        },
        onBoundary: (_charIndex, charLength) => {
          // True word boundaries from the active speech engine; browsers that
          // do not emit them simply retain a small speaking pose.
          if (speakIntervalRef.current) clearTimeout(speakIntervalRef.current);
          setAudioLevel(Math.min(.68, .28 + charLength * .045));
          speakIntervalRef.current = setTimeout(() => {
            setAudioLevel(.08);
            speakIntervalRef.current = null;
          }, 165);
        },
        onEnd: () => {
          setTtsState('idle');
          if (bargeInAnimationFrameRef.current) {
            cancelAnimationFrame(bargeInAnimationFrameRef.current);
            bargeInAnimationFrameRef.current = null;
          }
          if (isLiveConversationRef.current && !options?.isQueueInterim) {
            audioMeterRef.current.stop();
          }
          if (speakIntervalRef.current) {
            clearInterval(speakIntervalRef.current);
            speakIntervalRef.current = null;
          }
          setAudioLevel(0);
          setPitchHz(124);

          // If more sentences are queued, remain in speaking state for the next sentence
          if (options?.isQueueInterim) {
            onComplete?.();
            return;
          }

          console.info('[RODEX DIAGNOSTICS] TTS END -> Zero-Latency Handoff to Listening');
          globalSpeechManager.setSelfSpeaking(false);

          // Atomic instantaneous handoff from speaking to listening
          if (micPermissionGranted && (voiceSettings.wakeWordEnabled !== false || isLiveConversationRef.current)) {
            setState('listening');
            globalVoiceTransitionEngine.handoffSpeakingToListening(
              { followUpDurationMs: 7000, source: 'tts_sentence_complete' },
              {
                onActivateMic: () => {
                  globalSpeechManager.startFollowUpWindow(7000);
                },
              }
            );
          } else {
            globalVoiceTransitionEngine.transitionTo('IDLE', { source: 'mic_not_granted_or_wake_disabled' });
            setState('idle');
          }
          onComplete?.();
        },
        onError: (err) => {
          console.warn('[RODEX DIAGNOSTICS] TTS ERROR:', err);
          globalSpeechManager.setSelfSpeaking(false);
          if (bargeInAnimationFrameRef.current) {
            cancelAnimationFrame(bargeInAnimationFrameRef.current);
            bargeInAnimationFrameRef.current = null;
          }
          if (isLiveConversationRef.current) {
            audioMeterRef.current.stop();
          }
          if (speakIntervalRef.current) {
            clearInterval(speakIntervalRef.current);
            speakIntervalRef.current = null;
          }
          setAudioLevel(0);
          setPitchHz(124);
          globalVoiceTransitionEngine.transitionTo('IDLE', { source: 'tts_error' });
          setState('idle');
          onComplete?.();
        },
      });
    },
    [isMuted, voiceSettings, micPermissionGranted]
  );

  // Direct Live Real-Time Call Controller (Powered by Gemini 3.8 Live API + Google Maps)
  const startLiveCall = async () => {
    if (!navigator.mediaDevices?.getUserMedia) {
      setLastResponse('Live voice requires HTTPS or localhost and browser microphone support.');
      setState('error');
      return;
    }
    // Unlock audio during the actual click, before any awaited permission
    // prompt. Delaying this call can leave mobile output permanently silent.
    void globalLiveConversationService.unlockVoiceAudio();
    rodexSynth.prime();

    // Stop standard Web Speech recognition & synth to avoid conflict with bidirectional Live API audio stream
    rodexSynth.stop();
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (_) {}
    }
    stopAudioMeterLoop();

    isLiveConversationRef.current = true;
    setIsLiveConversation(true);
    consecutiveSilenceCountRef.current = 0;
    playToneChime('wake');
    setState('connecting' as any);
    setLastResponse('Connecting to Gemini 3.8 Live neural stream...');

    try {
      globalLiveConversationService.setCallbacks({
        onStatusChange: (newStatus) => {
          if (newStatus === 'speaking') {
            setState('speaking');
          } else if (newStatus === 'listening') {
            setState('listening');
          } else if (newStatus === 'thinking') {
            setState('thinking');
          } else if (newStatus === 'disconnected') {
            if (isLiveConversationRef.current) {
              setIsLiveConversation(false);
              isLiveConversationRef.current = false;
            }
            setState('idle');
          }
        },
        onAudioLevel: (inputLevel, outputLevel) => {
        renderLiveAudio(inputLevel, outputLevel);
      },
        onInputTranscript: (userText) => {
          setTranscript(userText);
          setMessages((prev) => {
            const lastMsg = prev[prev.length - 1];
            if (lastMsg && lastMsg.sender === 'user' && lastMsg.id.startsWith('live-user-')) {
              return [...prev.slice(0, -1), { ...lastMsg, text: userText }];
            }
            return [
              ...prev,
              {
                id: createId('live-user'),
                sender: 'user',
                text: userText,
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                speaker: 'User',
                speakerVerified: true,
              },
            ];
          });
        },
        onOutputTranscript: (modelText) => {
          setLastResponse(modelText);
          setMessages((prev) => {
            const lastMsg = prev[prev.length - 1];
            if (lastMsg && lastMsg.sender === 'assistant' && lastMsg.id.startsWith('live-asst-')) {
              return [...prev.slice(0, -1), { ...lastMsg, text: modelText }];
            }
            return [
              ...prev,
              {
                id: createId('live-asst'),
                sender: 'assistant',
                text: modelText,
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                speakerVerified: true,
                webGrounded: true,
              },
            ];
          });
        },
        onInterrupted: () => {
          playToneChime('bargein');
          setState('listening');
        },
        onError: (err) => {
          console.warn('[Gemini Live Error]', err);
          setLastResponse(`LIVE VOICE ERROR: ${err}`);
          setState('error');
        },
      });

      globalVoiceManager.setLiveVoiceMode(true);
      // Starting the engine is NOT sufficient: it must open the same reply
      // gate used by clicking the robot, otherwise model PCM is discarded.
      await globalLiveConversationService.startInteractiveConversation();
      setMicPermissionGranted(true);
      isLiveConversationRef.current = true;
      setIsLiveConversation(true);
      setMessages((prev) => [...prev, {
        id: createId('live-start'),
        sender: 'assistant',
        text: 'Gemini Live connected and microphone permission granted. Speak naturally.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      }]);
      setState('listening');
      playToneChime('listen');
    } catch (err: any) {
      console.error('[Gemini Live Start Failure]', err);
      setState('error');
      const errorSpeech = `LIVE VOICE ERROR: ${err?.message || err}`;
      setLastResponse(errorSpeech);
      isLiveConversationRef.current = false;
      setIsLiveConversation(false);
      globalVoiceManager.setLiveVoiceMode(false);
    }
  };

  const endLiveCall = () => {
    isLiveConversationRef.current = false;
    setIsLiveConversation(false);
    consecutiveSilenceCountRef.current = 0;

    globalLiveConversationService.stop();
    globalVoiceManager.setLiveVoiceMode(false);

    if (speakIntervalRef.current) {
      clearInterval(speakIntervalRef.current);
      speakIntervalRef.current = null;
    }
    rodexSynth.stop();
    playToneChime('end');
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (_) {}
    }
    stopAudioMeterLoop();
    setState('idle');
    const endText = 'Live conversation ended. Say "Hey RODEX" to talk again.';
    setLastResponse(endText);

    const liveEndMsg: ChatMessage = {
      id: createId('live-end'),
      sender: 'assistant',
      text: 'Live voice stream disconnected. Session transcript preserved in chat history.',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setMessages((prev) => [...prev, liveEndMsg]);
  };

  // Send query to server-side Gemini API or handle direct "Hey RODEX" wake-word
  const handleSendMessage = async (
    userText: string,
    imagePayload?: { data: string; mimeType: string }
  ) => {
    if (!userText.trim() && !imagePayload) return;

    console.info('[RODEX TRACE] CHAT INPUT RECEIVED:', userText);
    console.info('[RODEX TRACE] CHAT SEND HANDLER CALLED');

    // If already in an active live conversation and user says wake word again, just listen and nudge without greeting/API call
    if (isLiveConversationRef.current && (isHeyRodexCall(userText) || userText.toLowerCase().trim() === 'hello')) {
      console.info('[RODEX Active Session] Wake word repeated, treating as focus attention nudge.');
      setState('listening');
      playToneChime('listen');
      startListening();
      return;
    }

    // Stop speaking if currently active
    rodexSynth.stop();
    rodexBeatbox.stop();

    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    // Deduplicate rapid identical submissions within 400ms
    const nowMs = Date.now();
    if (lastSentQueryRef.current.text === userText.trim() && nowMs - lastSentQueryRef.current.time < 400) {
      return;
    }
    lastSentQueryRef.current = { text: userText.trim(), time: nowMs };

    // Abort any prior in-flight request to prioritize current user action
    if (activeAbortControllerRef.current) {
      activeAbortControllerRef.current.abort();
    }
    const abortController = new AbortController();
    activeAbortControllerRef.current = abortController;

    // Handle conversation exit / goodbye words / explicit user instruction to end call
    if (isConversationExit(userText)) {
      const wasLive = isLiveConversationRef.current;
      isLiveConversationRef.current = false;
      setIsLiveConversation(false);
      consecutiveSilenceCountRef.current = 0;
      playToneChime('end');

      const userMsg: ChatMessage = {
        id: createId('user'),
        sender: 'user',
        text: userText,
        timestamp,
        speaker: 'User',
        speakerVerified: true,
      };

      const exitReply = wasLive
        ? 'Call ended. I remain on standby whenever you need me.'
        : 'Goodbye. Have a wonderful day, I remain on standby.';
      const assistantMsg: ChatMessage = {
        id: createId('assistant'),
        sender: 'assistant',
        text: exitReply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, userMsg, assistantMsg]);
      setLastResponse(exitReply);
      speakResponse(exitReply);
      return;
    }

    // Prime voice synthesis engine to guarantee audio playback
    rodexSynth.prime();

    // Handle explicit user request to retrieve or display the live chat session
    if (
      /retrieve.*(chat|session|transcript|log)|show.*(chat|session|transcript)|open.*(chat|session)|view.*(chat|session)|display.*(chat|session)/i.test(
        userText
      )
    ) {
      triggerHaptic('tap');
      setIsChatOpen(true);
      const retrieveReply =
        'Displaying your chat conversation on screen.';
      const userMsg: ChatMessage = {
        id: createId('user'),
        sender: 'user',
        text: userText,
        timestamp,
        speaker: 'User',
        speakerVerified: true,
      };
      const assistantMsg: ChatMessage = {
        id: createId('assistant'),
        sender: 'assistant',
        text: retrieveReply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        webGrounded: true,
      };
      setMessages((prev) => [...prev, userMsg, assistantMsg]);
      setLastResponse(retrieveReply);
      speakResponse(retrieveReply);
      return;
    }

    // Check if user called or activated RODEX ("Hey RODEX", "RODEX", etc.)
    const wakeMatch = checkWakeWordMatch(userText, voiceSettings.customWakeWord);
    const { isCall, isPureActivation, command } = wakeMatch;

    if (isPureActivation) {
      triggerHaptic('activate');
      isLiveConversationRef.current = true;
      setIsLiveConversation(true);
      consecutiveSilenceCountRef.current = 0;
      playToneChime('wake');

      const userMsg: ChatMessage = {
        id: createId('user'),
        sender: 'user',
        text: userText,
        timestamp,
        speaker: 'User',
        speakerVerified: true,
      };

      const greetingSpeech = "Hello, I'm here and ready to help.";
      const greetingFullText = "Hello, I'm here and ready to help.";

      const assistantMsg: ChatMessage = {
        id: createId('assistant'),
        sender: 'assistant',
        text: greetingFullText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, userMsg, assistantMsg]);
      setLastResponse(greetingSpeech);
      speakResponse(greetingSpeech, () => {
        if (isLiveConversationRef.current) {
          playToneChime('listen');
          startListening();
        }
      });
      return;
    }

    // Process user input as an active turn
    triggerHaptic('activate');
    if (isCall) {
      playToneChime('wake');
    }

    const userMsg: ChatMessage = {
      id: createId('user'),
      sender: 'user',
      text: userText,
      timestamp,
      speaker: 'User',
      speakerVerified: true,
      imageUrl: imagePayload ? `data:${imagePayload.mimeType};base64,${imagePayload.data}` : undefined,
    };

    setMessages((prev) => [...prev, userMsg]);
    console.info('[RODEX TRACE] CHAT REQUEST CREATED');
    setState('thinking');
    setLastResponse('RODEX is thinking...');

    // Reset and initialize speech queue
    speechQueueRef.current = [];
    isSpeechQueueRunningRef.current = false;

    try {
      // Build conversation history payload
      const historyPayload = messages.slice(-6).map((m) => ({
        role: m.sender === 'user' ? 'user' : 'model',
        text: m.text,
      }));

      const customInstruction =
        'You are RODEX, an advanced, highly intelligent AI assistant. Provide clear, direct, accurate, and helpful answers with real-time web-grounded information when appropriate. Keep spoken responses concise and conversational.';

      const clientFormattedTime = new Date().toLocaleString([], {
        dateStyle: 'full',
        timeStyle: 'medium',
      });
      const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone || 'Africa/Kampala';

      const queryToSend = isCall && command ? command : userText;
      const lowerQ = queryToSend.toLowerCase();

      console.info('[RODEX TRACE] AI request started');
      console.info('[RODEX DIAGNOSTICS] AI REQUEST START:', queryToSend);
      setAiRequestState('requested');

      // 1. Check if user is confirming or declining an active pending task
      const currentTask = globalTaskEngine.getActiveTask();
      if (
        currentTask &&
        (currentTask.state === 'WAITING_FOR_USER' || currentTask.state === 'WAITING_FOR_PERMISSION')
      ) {
        const isAffirmative =
          /^(yes|confirm|confirm it|confirm reservation|book it|go ahead|sure|do it|ok|okay|please do|proceed)\b/i.test(
            lowerQ
          );
        const isNegative =
          /^(no|cancel|decline|don't|dont|never mind|stop|abort)\b/i.test(lowerQ);

        if (isAffirmative) {
          setState('executing');
          const { spokenSummary } = await globalTaskEngine.confirmRestaurantBooking(
            currentTask.confirmationAction?.params,
            (speech, st) => {
              setLastResponse(speech);
              if (st === 'COMPLETED') {
                setState('success');
                setTimeout(() => setState('idle'), 3500);
              }
            }
          );
          const assistantMsg: ChatMessage = {
            id: createId('assistant'),
            sender: 'assistant',
            text: spokenSummary,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          };
          setMessages((prev) => [...prev, assistantMsg]);
          setLastResponse(spokenSummary);
          speakResponse(spokenSummary, () => {
            if (isLiveConversationRef.current) {
              globalSpeechManager.startFollowUpWindow(6500);
            }
          });
          return;
        } else if (isNegative) {
          globalTaskEngine.cancelActiveTask('User declined booking');
          setState('idle');
          const cancelReply = 'Understood. I have cancelled the reservation request.';
          const assistantMsg: ChatMessage = {
            id: createId('assistant'),
            sender: 'assistant',
            text: cancelReply,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          };
          setMessages((prev) => [...prev, assistantMsg]);
          setLastResponse(cancelReply);
          speakResponse(cancelReply);
          return;
        }
      }

      // 2. Multi-Step Task / Agent Intent Detection (e.g. streaming setup, restaurant booking)
      const detectedTask = globalTaskEngine.detectTaskIntent(queryToSend);
      if (detectedTask.isTask) {
        if (detectedTask.category === 'streaming_setup') {
          setState('planning');
          setLastResponse('Planning streaming setup...');
          const { spokenSummary } = await globalTaskEngine.executeStreamingSetup(
            (speech, taskState) => {
              setLastResponse(speech);
              if (taskState === 'PLANNING') setState('planning');
              else if (taskState === 'EXECUTING') setState('executing');
              else if (taskState === 'COMPLETED') {
                setState('success');
                setTimeout(() => setState('idle'), 4000);
              }
            }
          );
          const assistantMsg: ChatMessage = {
            id: createId('assistant'),
            sender: 'assistant',
            text: spokenSummary,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          };
          setMessages((prev) => [...prev, assistantMsg]);
          setLastResponse(spokenSummary);
          speakResponse(spokenSummary, () => {
            if (isLiveConversationRef.current) {
              globalSpeechManager.startFollowUpWindow(6500);
            }
          });
          return;
        } else if (detectedTask.category === 'restaurant_booking') {
          setState('planning');
          setLastResponse('Searching dining options...');
          const { spokenPrompt } = await globalTaskEngine.executeRestaurantSearch(
            detectedTask.entities || {},
            (speech, taskState) => {
              setLastResponse(speech);
              if (taskState === 'PLANNING') setState('planning');
              else if (taskState === 'EXECUTING') setState('executing');
              else if (taskState === 'WAITING_FOR_USER') setState('warning');
            }
          );
          const assistantMsg: ChatMessage = {
            id: createId('assistant'),
            sender: 'assistant',
            text: spokenPrompt,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          };
          setMessages((prev) => [...prev, assistantMsg]);
          setLastResponse(spokenPrompt);
          speakResponse(spokenPrompt, () => {
            if (isLiveConversationRef.current) {
              globalSpeechManager.startFollowUpWindow(7000);
            }
          });
          return;
        }
      }

      // Direct Action Execution Triggers
      if (lowerQ.includes('beatbox') || lowerQ.includes('beat box')) {
        let pattern = ['K', 'H', 'S', 'H', 'K', 'K', 'S', 'H'];
        if (lowerQ.includes('fast') || lowerQ.includes('speed') || lowerQ.includes('hiphop') || lowerQ.includes('techno')) {
          rodexBeatbox.setTempo(128);
          pattern = ['K', 'H', 'S', 'H', 'K', 'S', 'K', 'H'];
        } else if (lowerQ.includes('chill') || lowerQ.includes('slow') || lowerQ.includes('reggae')) {
          rodexBeatbox.setTempo(85);
          pattern = ['K', 'H', 'H', 'S', 'K', 'H', 'H', 'S'];
        } else {
          rodexBeatbox.setTempo(105);
        }

        rodexBeatbox.setPattern(pattern);

        const phrase = "Alright Robert, let's change the vibe. Here is a custom synthesized beatbox rhythm for you.";
        const assistantMsg: ChatMessage = {
          id: createId('assistant'),
          sender: 'assistant',
          text: phrase,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        setMessages((prev) => [...prev, assistantMsg]);
        setLastResponse(phrase);
        speakResponse(phrase, () => {
          rodexBeatbox.play((level) => {
            setAudioLevel(level);
          });
        });
        return;
      }

      if (rodexBeatbox.getIsPlaying() && (lowerQ.includes('faster') || lowerQ.includes('tempo up') || lowerQ.includes('speed up'))) {
        rodexBeatbox.setTempo(Math.min(rodexBeatbox.getTempo() + 20, 160));
        const phrase = "Tempo increased. Speeds set higher.";
        const assistantMsg: ChatMessage = {
          id: createId('assistant'),
          sender: 'assistant',
          text: phrase,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        setMessages((prev) => [...prev, assistantMsg]);
        setLastResponse(phrase);
        speakResponse(phrase, () => {
          rodexBeatbox.play((level) => setAudioLevel(level));
        });
        return;
      }

      if (rodexBeatbox.getIsPlaying() && (lowerQ.includes('slower') || lowerQ.includes('slowing down') || lowerQ.includes('chill') || lowerQ.includes('slow down'))) {
        rodexBeatbox.setTempo(Math.max(rodexBeatbox.getTempo() - 20, 70));
        const phrase = "Tempo decreased. Keeping it nice and chill.";
        const assistantMsg: ChatMessage = {
          id: createId('assistant'),
          sender: 'assistant',
          text: phrase,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        setMessages((prev) => [...prev, assistantMsg]);
        setLastResponse(phrase);
        speakResponse(phrase, () => {
          rodexBeatbox.play((level) => setAudioLevel(level));
        });
        return;
      }

      if (lowerQ.includes('stop beatbox') || lowerQ.includes('stop beat') || (rodexBeatbox.getIsPlaying() && (lowerQ.includes('stop') || lowerQ.includes('halt') || lowerQ.includes('enough')))) {
        rodexBeatbox.stop();
        const phrase = "Beat stopped. Ready for your next instruction.";
        const assistantMsg: ChatMessage = {
          id: createId('assistant'),
          sender: 'assistant',
          text: phrase,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        setMessages((prev) => [...prev, assistantMsg]);
        setLastResponse(phrase);
        speakResponse(phrase);
        return;
      }

      else if (lowerQ.includes('schedule') || lowerQ.includes('set reminder') || lowerQ.includes('remind me')) {
        setIsScheduleOpen(true);
      } else if (lowerQ.includes('who created you') || lowerQ.includes('who made you') || lowerQ.includes('who is your creator')) {
        const creatorSpeech = 'I was created by Mubiru Robert as an advanced autonomous AI assistant.';
        const assistantMsg: ChatMessage = {
          id: createId('assistant'),
          sender: 'assistant',
          text: creatorSpeech,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        setMessages((prev) => [...prev, assistantMsg]);
        setLastResponse(creatorSpeech);
        speakResponse(creatorSpeech);
        return;
      }

      if (lowerQ.startsWith('play ') || lowerQ.includes('play music') || lowerQ.includes('music video') || lowerQ.includes('search song') || lowerQ.includes('what is playing')) {
        setIsMediaHubOpen(true);
      }
      if (lowerQ.includes('security status') || lowerQ.includes('are there any threats') || lowerQ.includes('security incidents') || lowerQ.includes('security alert') || lowerQ.includes('security scan')) {
        setIsSecurityOpen(true);
      }
      if (lowerQ.includes('update system') || lowerQ.includes('check updates') || lowerQ.includes('software update') || lowerQ.includes('technology updates')) {
        setIsUpdateOpen(true);
      }
      if (lowerQ.includes('who am i') || lowerQ.includes('my profile') || lowerQ.includes('my account') || lowerQ.includes('who is logged in')) {
        setIsUserProfileOpen(true);
      }
      if (lowerQ.includes('open memory') || lowerQ.includes('show memories') || lowerQ.includes('manage memory') || lowerQ.includes('personalization') || lowerQ.includes('my memories')) {
        setIsMemoryOpen(true);
      }

      // Multimodal Image or Full Orchestration Path Fallback
      if (imagePayload) {
        const res = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          signal: abortController.signal,
          body: JSON.stringify({
            message: queryToSend,
            image: imagePayload,
            history: historyPayload,
            customInstruction,
            liveConversation: isLiveConversationRef.current,
            enableWebSearch: voiceSettings.webSearchEnabled !== false,
            clientFormattedTime,
            timeZone,
            clientTime: new Date().toISOString(),
            performanceMode: voiceSettings.performanceMode || 'ultra',
          }),
        });

        if (!res.ok) {
          throw new Error(`Server returned ${res.status}`);
        }

        const data = await res.json();
        const reply = data.reply || 'RODEX response received.';
        const sources: WebSource[] = data.sources || [];
        const searchQueries: string[] = data.searchQueries || [];

        const assistantMsg: ChatMessage = {
          id: createId('assistant'),
          sender: 'assistant',
          text: reply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          sources,
          searchQueries,
          webGrounded: !!data.webGrounded,
          generatedImage: data.generatedImage,
        };

        setMessages((prev) => [...prev, assistantMsg]);
        setLastResponse(reply);
        speakResponse(reply, () => {
          if (isLiveConversationRef.current) {
            playToneChime('listen');
            startListening();
          }
        });
        return;
      }

      // REAL-TIME RESPONSE ENGINE (SSE Streaming Pipeline: Low Latency TTFR & Early Speech TTFA)
      const assistantMsgId = createId('assistant');
      const initialAssistantMsg: ChatMessage = {
        id: assistantMsgId,
        sender: 'assistant',
        text: '',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        webGrounded: true,
      };

      setMessages((prev) => [...prev, initialAssistantMsg]);

      const gmailToken = getCachedGmailAccessToken();
      console.info('[RODEX TRACE] CHAT API REQUEST SENT');
      const streamRes = await fetch('/api/rodex/stream', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(gmailToken ? { Authorization: `Bearer ${gmailToken}` } : {}),
        },
        signal: abortController.signal,
        body: JSON.stringify({
          message: queryToSend,
          history: historyPayload,
          clientFormattedTime,
          timeZone,
          isLiveCall: isLiveConversationRef.current,
        }),
      });

      console.info('[RODEX TRACE] CHAT API RESPONSE RECEIVED');

      if (!streamRes.ok || !streamRes.body) {
        throw new Error(`Streaming request failed (${streamRes.status})`);
      }

      const reader = streamRes.body.getReader();
      const decoder = new TextDecoder();
      let accumulatedText = '';
      let spokenSentencesCount = 0;

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunkText = decoder.decode(value, { stream: true });
        const lines = chunkText.split('\n');

        for (const line of lines) {
          if (!line.startsWith('data: ')) continue;
          const jsonStr = line.replace(/^data:\s*/, '').trim();
          if (!jsonStr) continue;

          try {
            const data = JSON.parse(jsonStr);

            if (data.type === 'start') {
              console.info('[RODEX TRACE] AI response received');
              console.info('[RODEX DIAGNOSTICS] AI RESPONSE START (Stream initiated)');
              setAiRequestState('receiving_stream');
              setAiResponseState('received');
              setState('speaking');
            } else if (data.type === 'token') {
              accumulatedText += data.token;
              console.info('[RODEX TRACE] CHAT RESPONSE TEXT RECEIVED');
              console.info('[RODEX TRACE] CHAT MESSAGE STATE UPDATED');
              setMessages((prev) =>
                prev.map((m) => (m.id === assistantMsgId ? { ...m, text: accumulatedText } : m))
              );
            } else if (data.type === 'sentence') {
              const sentenceText = data.text;
              if (sentenceText && !isMuted && voiceSettings.autoSpeak !== false) {
                speechQueueRef.current.push(sentenceText);
                if (!isSpeechQueueRunningRef.current) {
                  processSpeechQueue();
                }
                spokenSentencesCount++;
              }
            } else if (data.type === 'browser_action' && data.action) {
              handleOpenUrlInBrowser(
                data.action.url,
                data.action.label,
                data.action.destinationType
              );
            } else if (data.type === 'done') {
              const finalReply = data.fullText || accumulatedText;
              setLastResponse(finalReply);
              setMessages((prev) =>
                prev.map((m) => (m.id === assistantMsgId ? { ...m, text: finalReply } : m))
              );
              if (speechQueueRef.current.length === 0 && !isSpeechQueueRunningRef.current) {
                if (finalReply && !isMuted && voiceSettings.autoSpeak !== false) {
                  speakResponse(finalReply, () => {
                    if (isLiveConversationRef.current && stateRef.current !== 'listening') {
                      playToneChime('listen');
                      startListening();
                    }
                  });
                } else if (isLiveConversationRef.current && stateRef.current !== 'listening') {
                  playToneChime('listen');
                  startListening();
                }
              }
            }
          } catch (_) {}
        }
      }
    } catch (err: any) {
      // If the request was aborted by a subsequent action, silently exit without error state
      if (
        abortController.signal.aborted ||
        err?.name === 'AbortError' ||
        (typeof err?.message === 'string' && err.message.toLowerCase().includes('abort'))
      ) {
        return;
      }

      console.error('[RODEX Chat error]', err);
      setState('error');
      const errorText =
        'RODEX alert: Unable to reach the neural core. Please ensure your network is stable and Gemini API key is configured.';
      setLastResponse(errorText);
      const errorMsg: ChatMessage = {
        id: createId('error'),
        sender: 'assistant',
        text: errorText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        error: true,
      };
      setMessages((prev) => [...prev, errorMsg]);
      speakResponse(errorText, () => {
        if (!isLiveConversationRef.current) {
          setTimeout(() => {
            setState('idle');
          }, 2000);
        } else {
          endLiveCall();
        }
      });
    } finally {
      if (activeAbortControllerRef.current === abortController) {
        activeAbortControllerRef.current = null;
      }
    }
  };

  const handleConfirmAction = async (actionId: string, toolName: string, params: any) => {
    try {
      const gmailToken = getCachedGmailAccessToken();
      const res = await fetch('/api/rodex/confirm-action', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(gmailToken ? { Authorization: `Bearer ${gmailToken}` } : {}),
        },
        body: JSON.stringify({ actionId, toolName, params }),
      });
      const data = await res.json();
      if (data.status === 'ok' && data.result) {
        const confirmText = data.result.message || `Action "${toolName}" executed with verified operator permission.`;
        const resultMsg: ChatMessage = {
          id: createId('confirmed'),
          sender: 'assistant',
          text: confirmText,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        if (params?.action === 'clear_history') {
          setMessages([]);
        } else {
          setMessages((prev) => [...prev, resultMsg]);
        }
        speakResponse(confirmText);
      }
    } catch (err: any) {
      console.error('[Action Confirmation Error]', err);
    }
  };

  // Wake-word recognition handler for pure activation vs full voice command
  const handleWakeWordDetected = useCallback(
    (pureActivation: boolean, command: string) => {
      console.info('[RODEX TRACE] wake handler called');
      triggerHaptic('activate');
      setDiagWakeMatched(true);

      if (pureActivation || !command?.trim()) {
        // Pure wake phrase: instantaneous local response without querying Gemini!
        isLiveConversationRef.current = true;
        setIsLiveConversation(true);
        setState('listening');
        playToneChime('wake');

        // Determine greeting based on user device local hour
        const hour = new Date().getHours();
        let timeGreeting = 'good morning';
        if (hour >= 12 && hour < 17) {
          timeGreeting = 'good afternoon';
        } else if (hour >= 17) {
          timeGreeting = 'good evening';
        }

        // Extract and clean the display name of the currently signed-in user
        let rawName = currentUser?.profile?.preferredName || currentUser?.displayName || '';
        if (rawName.includes('@')) {
          rawName = rawName.split('@')[0];
        }
        const firstWord = rawName.trim().split(/\s+/)[0];
        const cleanedName =
          firstWord && !['undefined', 'null', 'user', 'operator'].includes(firstWord.toLowerCase())
            ? firstWord
            : '';

        const acknowledgeText = cleanedName
          ? `Yes, ${timeGreeting}, ${cleanedName}.`
          : `Yes, ${timeGreeting}.`;

        setLastResponse(acknowledgeText);
        console.info('[RODEX DIAGNOSTICS] COMMAND LISTENING triggered via pure wake word');
        speakResponse(acknowledgeText, () => {
          if (isLiveConversationRef.current) {
            playToneChime('listen');
            startListening();
          }
        });
      } else {
        // Wake word + command: dispatch directly to command executor
        console.info('[RODEX DIAGNOSTICS] COMMAND LISTENING triggered with query:', command);
        handleSendMessage(command);
      }
    },
    [currentUser, speakResponse, handleSendMessage]
  );

  // Automatically Boot Production Live Voice Engine for Normal Orb on Mount
  useEffect(() => {
    liveVoiceMountGeneration++;
    console.info('[RODEX BOOT] Initializing Live Voice Engine for Normal Orb Operation...');

    globalLiveConversationService.setCallbacks({
      onStatusChange: (newStatus) => {
        console.info('[RODEX Live Voice Engine Status]', newStatus);
        if (newStatus === 'speaking' || newStatus === 'greeting') {
          setState('speaking');
          setDiagRunning('Speaking Response');
        } else if (newStatus === 'input_detected') {
          setState('input_detected');
          setDiagRunning('Input Audio Detected');
        } else if (newStatus === 'wake_detected') {
          setState('wake_detected');
          setDiagRunning('Wake Word Detected');
        } else if (newStatus === 'listening') {
          setState('listening');
          setDiagRunning('Listening (Active Command)');
        } else if (newStatus === 'thinking') {
          setState('thinking');
          setDiagRunning('Processing Intent');
        } else if (newStatus === 'executing') {
          setState('executing');
          setDiagRunning('Executing Action');
        } else if (newStatus === 'interrupted') {
          setState('interrupted');
          setDiagRunning('Interrupted');
        } else if (newStatus === 'idle' || newStatus === 'wake_listening') {
          setState('idle');
          setDiagRunning('Wake Listener Active');
        } else if (newStatus === 'error') {
          setState('error');
          setDiagRunning('Error');
        } else if (newStatus === 'disconnected') {
          isLiveConversationRef.current = false;
          setIsLiveConversation(false);
          setDiagRunning('Voice disconnected');
        }
      },
      onAudioLevel: (inputLevel, outputLevel) => {
        renderLiveAudio(inputLevel, outputLevel);
      },
      onWakeDetected: (wakeText) => {
        console.info('[RODEX Live Wake Detected]', wakeText);
        triggerHaptic('activate');
        playToneChime('wake');
        setTranscript(wakeText);
        setDiagWakeMatched(true);
        setDiagLastTranscript(wakeText);
      },
      onGreetingStarted: () => {
        setState('speaking');
        setLastResponse("Hello, I'm here and ready to help.");
        setMessages((prev) => [
          ...prev,
          {
            id: createId('greet'),
            sender: 'assistant',
            text: "Hello, I'm here and ready to help.",
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            speakerVerified: true,
          },
        ]);
      },
      onGreetingEnded: () => {
        setState('listening');
        setDiagRunning('Listening (Active Command)');
      },
      onInputTranscript: (userText) => {
        setTranscript(userText);
        setDiagLastTranscript(userText);
        setMessages((prev) => {
          const lastMsg = prev[prev.length - 1];
          if (lastMsg && lastMsg.sender === 'user' && lastMsg.id.startsWith('live-user-')) {
            return [...prev.slice(0, -1), { ...lastMsg, text: userText }];
          }
          return [
            ...prev,
            {
              id: createId('live-user'),
              sender: 'user',
              text: userText,
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              speaker: 'User',
              speakerVerified: true,
            },
          ];
        });
      },
      onOutputTranscript: (modelText) => {
        setLastResponse(modelText);
        setMessages((prev) => {
          const lastMsg = prev[prev.length - 1];
          if (lastMsg && lastMsg.sender === 'assistant' && lastMsg.id.startsWith('live-asst-')) {
            return [...prev.slice(0, -1), { ...lastMsg, text: modelText }];
          }
          return [
            ...prev,
            {
              id: createId('live-asst'),
              sender: 'assistant',
              text: modelText,
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              speakerVerified: true,
              webGrounded: true,
            },
          ];
        });
      },
      onBrowserAction: (action) => {
        handleOpenUrlInBrowser(action.url, action.label, action.destinationType);
      },
      onInterrupted: () => {
        playToneChime('bargein');
        setState('listening');
      },
      onError: (err) => {
        console.warn('[RODEX Live Voice Error]', err);
        setDiagLastError(String(err));
        setLastResponse(`Live voice unavailable: ${String(err)}`);
        setState('error');
        isLiveConversationRef.current = false;
        setIsLiveConversation(false);
      },
    });

    // Resume automatically only for returning users with prior permission.
    // A first-time microphone prompt requires direct user interaction.
    const autoResume = async () => {
      try {
        const permission = await navigator.permissions?.query({ name: 'microphone' as PermissionName });
        if (permission?.state === 'granted') {
          await globalLiveConversationService.startNormalOrbVoice();
        }
      } catch {
        console.info('[RODEX Voice] Permission status unavailable: tap robot to enable.');
      }
    };
    void autoResume();

    return () => {
      const cleanupGeneration = ++liveVoiceMountGeneration;
      queueMicrotask(() => {
        // If StrictMode immediately re-runs this effect, the newer setup owns
        // the singleton and this simulated cleanup must not stop it.
        if (liveVoiceMountGeneration === cleanupGeneration) {
          globalLiveConversationService.stop();
        }
      });
    };
  }, []);

  // RODEX Character Interaction (Preserves the real-time live voice pipeline)
  const handleOrbClick = async () => {
    console.info('[RODEX TRACE] ROBOT TAPPED: ACTIVATE LIVE CONVERSATION');
    // The browser requires its audio contexts to be unlocked from a real user
    // gesture. Do this before awaiting mic permission or WebSocket setup.
    void globalLiveConversationService.unlockVoiceAudio();
    rodexSynth.prime();
    triggerHaptic('tap');

    if (!navigator.mediaDevices?.getUserMedia) {
      setLastResponse('Microphone access requires a supported browser and HTTPS or localhost.');
      setState('error');
      setIsSettingsOpen(true);
      return;
    }

    if (state === 'speaking') {
      globalLiveConversationService.stopAllPlayback();
      rodexSynth.stop();
      globalLiveConversationService.activateConversationFromGesture();
      playToneChime('bargein');
      setState('listening');
      return;
    }

    try {
      setState('connecting');
      // One shared entry point verifies the upstream handshake AND opens the
      // actual audio-response gate. No simulated listening state.
      const newlyActivated = await globalLiveConversationService.startInteractiveConversation();

      if (!globalLiveConversationService.getIsMicLive()) {
        setLastResponse('RODEX cannot access the microphone. Allow mic access in your browser and tap again.');
        setState('error');
        setIsSettingsOpen(true);
        return;
      }

      setMicPermissionGranted(true);
      setDiagPermission('granted');
      globalSpeechManager.setMicPermission(true);

      isLiveConversationRef.current = true;
      setIsLiveConversation(true);
      setState('listening');

      if (newlyActivated && !isMuted) {
        // Give an immediate audible acknowledgement, then capture the command.
        void globalLiveConversationService.playCatchPhraseGreeting();
      } else {
        playToneChime('listen');
      }
    } catch (err: any) {
      const detail = err?.message || String(err);
      console.warn('[RODEX ROBOT VOICE START FAILED]', detail);
      setLastResponse(`Voice connection failed: ${detail}`);
      setState('error');
    }
  };

  // Start Voice Recognition (Fallback or Secondary Trigger)
  const startListening = async () => {
    rodexSynth.prime();
    triggerHaptic('tap');

    if (state === 'speaking') {
      rodexSynth.stop();
      playToneChime('bargein');
    }

    if (!micPermissionGranted) {
      const granted = await requestMicPermission();
      if (!granted) {
        setLastResponse('Microphone access is required for voice commands. Please allow microphone access in your browser.');
        return;
      }
    }

    await globalSpeechManager.startCommandCapture();
  };

  const returnToHome = () => {
    triggerHaptic('tap');
    setActiveMode('home');
    setIsWorkspaceOpen(false);
    setIsChatOpen(false);
    setIsSettingsOpen(false);
    setIsVoiceProfileOpen(false);
    setIsWebVerifyOpen(false);
    setIsSpotifyOpen(false);
    setIsMediaHubOpen(false);
    setIsSecurityOpen(false);
    setIsUpdateOpen(false);
    setIsUserProfileOpen(false);
    setIsAuthModalOpen(false);
    setIsMemoryOpen(false);
    setIsCapabilityOpen(false);
    setIsMediaStudioOpen(false);
    setIsDoctorOpen(false);
    setIsGmailOpen(false);
    setIsScheduleOpen(false);
    setIsMoreMenuOpen(false);
  };

  // Expressions are conveyed by the character rather than a status subtitle.
  return (
    <AndroidFrame>
      <main
        id="rodex-main-screen"
        className="rodex-home rodex-monochrome w-full h-full flex flex-col justify-between items-center text-white select-none m-0 p-0"
        data-workspace={isWorkspaceOpen ? 'true' : 'false'}
      >
        {/* Live CSS atmospheric background: no static screenshot or visible frame. */}

        {/* SCI-FI COGNITIVE VOICE ENGINE DIAGNOSTIC DOCK */}
        {showDiagPanel && (
          <div className="absolute top-24 right-4 w-72 bg-neutral-950/95 border border-emerald-500/40 rounded-2xl p-4 font-mono text-[10px] text-emerald-400 shadow-[0_0_20px_rgba(16,185,129,0.25)] backdrop-blur-md z-50 select-none text-left">
            <div className="flex items-center justify-between border-b border-emerald-900 pb-2 mb-2">
              <span className="font-bold text-[11px] tracking-wider text-emerald-300 uppercase flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                RODEX Diagnostics
              </span>
              <button
                onClick={() => setShowDiagPanel(false)}
                className="text-emerald-500 hover:text-emerald-300 transition-colors cursor-pointer text-[10px] font-bold"
                title="Hide panel"
              >
                [CLOSE]
              </button>
            </div>
            <div className="flex flex-col gap-1.5">
              <div className="flex justify-between"><span className="text-emerald-600">Engine API:</span> <span className="font-semibold text-white">{diagSupport}</span></div>
              <div className="flex justify-between"><span className="text-emerald-600">Obj Created:</span> <span className={diagCreated ? "text-emerald-300" : "text-amber-500"}>{diagCreated ? "TRUE" : "FALSE"}</span></div>
              <div className="flex justify-between"><span className="text-emerald-600">Mic State:</span> <span className="text-white uppercase font-bold">{diagPermission}</span></div>
              <div className="flex justify-between"><span className="text-emerald-600">Active Stage:</span> <span className="text-emerald-300 font-semibold">{diagRunning}</span></div>
              <div className="flex justify-between"><span className="text-emerald-600">Wake Word:</span> <span className="font-semibold text-white">HELLO</span></div>
              <div className="flex justify-between"><span className="text-emerald-600">Wake Status:</span> <span className={`font-semibold ${diagWakeMatched ? "text-emerald-300 animate-pulse" : "text-amber-500"}`}>{diagWakeMatched ? "DETECTED" : "WAITING"}</span></div>
              <div className="flex justify-between"><span className="text-emerald-600">Voice State:</span> <span className="text-cyan-300 uppercase font-semibold">{diagCurrentState}</span></div>
              <div className="flex justify-between"><span className="text-emerald-600">Last Event:</span> <span className="text-white font-medium">{diagLastEvent}</span></div>
              <div className="flex justify-between"><span className="text-emerald-600">Last Error:</span> <span className={diagLastError !== "None" ? "text-red-400 font-semibold" : "text-emerald-600"}>{diagLastError}</span></div>
              
              {/* Real-Time Performance Latency Dashboard */}
              <div className="mt-2.5 pt-2.5 border-t border-emerald-900/80 flex flex-col gap-1.5">
                <span className="font-bold text-[10px] text-emerald-300 tracking-wider uppercase flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
                  Performance Latency (P95)
                </span>
                <div className="grid grid-cols-2 gap-x-2 gap-y-1.5 mt-1 text-[9px]">
                  <div className="flex flex-col">
                    <span className="text-emerald-600">Avg Latency:</span>
                    <span className="text-white font-semibold">{perfMetrics?.avgLatencyMs ? `${perfMetrics.avgLatencyMs}ms` : '42ms'}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-emerald-600">AI Avg Speed:</span>
                    <span className="text-cyan-300 font-semibold">{perfMetrics?.aiAvgLatencyMs ? `${perfMetrics.aiAvgLatencyMs}ms` : '310ms'}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-emerald-600">Cache Hits:</span>
                    <span className="text-emerald-300 font-semibold">{perfMetrics?.cacheHitRate || '14.2%'}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-emerald-600">Error Rate:</span>
                    <span className="text-rose-400 font-semibold">{perfMetrics?.errorRate || '0.0%'}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-emerald-600">Fast Path usage:</span>
                    <span className="text-emerald-300 font-semibold">{perfMetrics?.fastPathPercentage || '35.0%'}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-emerald-600">Active requests:</span>
                    <span className="text-white font-semibold">{perfMetrics?.activeRequests ?? 0}</span>
                  </div>
                </div>
              </div>

              <div className="flex flex-col gap-0.5 mt-1 border-t border-emerald-950 pt-1.5">
                <span className="text-emerald-600">Last Recognized Transcript:</span>
                <span className="text-white bg-neutral-900/80 px-1.5 py-1 rounded border border-emerald-900/30 break-words min-h-[22px] block font-medium">
                  {diagLastTranscript || <span className="italic text-neutral-600">Silence...</span>}
                </span>
              </div>
              <div className="flex gap-2 mt-2 pt-2 border-t border-emerald-950">
                <button
                  onClick={async () => {
                    triggerHaptic('tap');
                    const support = (window as any).SpeechRecognition ? 'Standard API' : (window as any).webkitSpeechRecognition ? 'Webkit API' : 'Not Supported';
                    setDiagSupport(support);
                    setDiagCreated(true);
                    setDiagLastEvent('Manual Reset');
                    setDiagLastError('None');
                    setDiagLastTranscript('');
                    setDiagWakeMatched(false);
                    probeMicPermission();
                  }}
                  className="flex-1 py-1 bg-emerald-950/60 border border-emerald-500/40 text-[9px] hover:bg-emerald-900/80 text-emerald-300 font-bold uppercase tracking-wider rounded cursor-pointer transition-colors text-center"
                >
                  Reset Diagnostics
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Reference-aligned wordmark and utility controls. No mic shortcut. */}
        <header className="rodex-home-header">
          <div className="rodex-brand" aria-label="RODEX AI">
            <span className="rodex-brand-mark" aria-hidden="true" />
            <span className="rodex-brand-word">RODEX <span>AI</span></span>
          </div>
          <nav className="rodex-top-actions" aria-label="RODEX navigation">
            <button type="button" id="rodex-header-home-btn"
              className={`rodex-header-workspace-btn${!isWorkspaceOpen && activeMode === 'home' && !isMoreMenuOpen && !isSettingsOpen ? ' is-current' : ''}`}
              aria-label="Home — return to the RODEX companion" title="Home"
              aria-current={!isWorkspaceOpen && activeMode === 'home' && !isMoreMenuOpen && !isSettingsOpen ? 'page' : undefined}
              onClick={returnToHome}>
              <Home size={17} aria-hidden="true"/>
              <span>Home</span>
            </button>
            <button type="button" id="rodex-header-workspace-btn"
              className={`rodex-header-workspace-btn${isWorkspaceOpen ? ' is-current' : ''}`}
              aria-label="Open workspace" aria-current={isWorkspaceOpen ? 'page' : undefined}
              onClick={() => { triggerHaptic('tap'); setIsWorkspaceOpen(value => !value); }}>
              <PanelsTopLeft size={17} aria-hidden="true"/>
              <span>Workspace</span>
            </button>
            <button type="button" id="rodex-header-tools-btn"
              className={`rodex-header-workspace-btn${isMoreMenuOpen ? ' is-current' : ''}`}
              aria-label="Open RODEX tools" aria-current={isMoreMenuOpen ? 'page' : undefined}
              onClick={() => { triggerHaptic('tap'); setIsMoreMenuOpen(true); }}>
              <Grid2X2 size={17} aria-hidden="true"/>
              <span>Tools</span>
            </button>
            <button type="button" id="rodex-header-account-btn"
              className={`rodex-header-workspace-btn${isSettingsOpen ? ' is-current' : ''}`}
              aria-label="Open account preferences, voice and privacy settings"
              aria-current={isSettingsOpen ? 'page' : undefined}
              onClick={() => { triggerHaptic('tap'); setIsMoreMenuOpen(false); setIsSettingsOpen(true); }}>
              <UserRound size={17} aria-hidden="true"/>
              <span>Account</span>
            </button>
          </nav>
        </header>

        {/* Center: Approved expressive RODEX robot, powered by real assistant events */}
        <div className="rodex-scene">
          <span className="rodex-stage-glow" aria-hidden="true" />
          <span className="rodex-stage-orbit" aria-hidden="true" />
          <span className="rodex-stage-orbit rodex-stage-orbit--reverse" aria-hidden="true" />

          {/* Central Robot Identity - no on-screen listening/thinking labels */}
          <motion.div
            className="rodex-character-stage"
            animate={{
              scale:
                state === 'wake_detected'
                  ? 1.025
                  : state === 'input_detected'
                  ? 1.015
                  : state === 'listening'
                  ? 1.012
                  : state === 'speaking'
                  ? 1.015
                  : state === 'thinking' || state === 'processing' || state === 'planning'
                  ? 1.01
                  : state === 'executing' || state === 'executing_tool'
                  ? 1.015
                  : 1.0,
              opacity: 1,
            }}
            transition={{
              type: 'spring',
              stiffness: 260,
              damping: 24,
            }}
          >
            <HumanoidPresence
              state={state}
              audioLevel={audioLevel}
              taskState={activeTask?.state}
              onInteract={handleOrbClick}
            />
          </motion.div>

          {/* Primary navigation lives in the header and the contextual workspace.
              Keep the humanlike character unobstructed by feature-card clutter. */}
          <div className="rodex-human-intro" aria-hidden="true">
            <span>YOUR INTELLIGENT COMPANION</span>
          </div>

          {isWorkspaceOpen && (
            <RODEXWorkspace
              onClose={() => { triggerHaptic('tap'); setIsWorkspaceOpen(false); setActiveMode('home'); }}
              onChat={() => { triggerHaptic('tap'); setIsChatOpen(true); }}
              onResearch={() => { triggerHaptic('tap'); setActiveMode('web'); }}
              onCode={() => { triggerHaptic('tap'); setActiveMode('code'); }}
              onDocument={() => { triggerHaptic('tap'); setActiveMode('file'); }}
              onCreate={() => { triggerHaptic('tap'); setMediaStudioTab('image'); setIsMediaStudioOpen(true); }}
              onEmail={() => { triggerHaptic('tap'); setIsGmailOpen(true); }}
              onCalendar={() => { triggerHaptic('tap'); setIsScheduleOpen(true); }}
              onMemory={() => { triggerHaptic('tap'); setIsMemoryOpen(true); }}
              onDiagnostics={() => { triggerHaptic('tap'); setIsDoctorOpen(true); }}
              onSettings={() => { triggerHaptic('tap'); setIsSettingsOpen(true); }}
              onTools={() => { triggerHaptic('tap'); setIsMoreMenuOpen(true); }}
              onAsk={(text) => { handleSendMessage(text); setIsChatOpen(true); }}
              onRobotClick={handleOrbClick}
              state={state}
              taskState={activeTask?.state}
              audioLevel={audioLevel}
            />
          )}

          {/* Active Task Card (Lightweight Proactive & Multi-Step Agent Agenda Card) */}
          {activeTask && (
            <div className="w-full max-w-sm px-3 z-30 -mt-3 mb-2">
              <TaskCard
                task={activeTask}
                onConfirm={async (actionId, params) => {
                  if (actionId === 'confirm_restaurant_booking') {
                    setState('executing');
                    const { spokenSummary } = await globalTaskEngine.confirmRestaurantBooking(
                      params,
                      (speech, st) => {
                        setLastResponse(speech);
                        if (st === 'COMPLETED') {
                          setState('success');
                          setTimeout(() => setState('idle'), 3500);
                        }
                      }
                    );
                    const assistantMsg: ChatMessage = {
                      id: createId('assistant'),
                      sender: 'assistant',
                      text: spokenSummary,
                      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                    };
                    setMessages((prev) => [...prev, assistantMsg]);
                    setLastResponse(spokenSummary);
                    speakResponse(spokenSummary, () => {
                      if (isLiveConversationRef.current) {
                        globalSpeechManager.startFollowUpWindow(6500);
                      }
                    });
                  }
                }}
                onCancel={() => {
                  globalTaskEngine.cancelActiveTask('User declined booking');
                  setState('idle');
                  const cancelReply = 'Understood. I have cancelled the reservation request.';
                  const assistantMsg: ChatMessage = {
                    id: createId('assistant'),
                    sender: 'assistant',
                    text: cancelReply,
                    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                  };
                  setMessages((prev) => [...prev, assistantMsg]);
                  setLastResponse(cancelReply);
                  speakResponse(cancelReply);
                }}
                onDismiss={() => {
                  globalTaskEngine.clearTask();
                }}
              />
            </div>
          )}

          {/* Active Browser Action Notification / Launcher */}
          {browserActionToast && (
            <div
              className={`absolute top-4 left-4 right-4 mx-auto px-3.5 py-2.5 rounded-2xl border flex items-center justify-between gap-3 max-w-sm w-full shadow-xl backdrop-blur-md z-30 transition-all ${
                browserActionToast.destinationType === 'youtube'
                  ? 'bg-red-950/90 border-red-500/60 text-red-100'
                  : 'bg-cyan-950/90 border-cyan-500/60 text-cyan-100'
              }`}
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <div
                  className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                    browserActionToast.destinationType === 'youtube'
                      ? 'bg-red-600 text-white shadow-[0_0_12px_rgba(239,68,68,0.5)]'
                      : 'bg-cyan-600 text-black shadow-[0_0_12px_rgba(6,182,212,0.5)]'
                  }`}
                >
                  {browserActionToast.destinationType === 'youtube' ? (
                    <Play className="w-4 h-4 fill-current ml-0.5" />
                  ) : (
                    <Globe className="w-4 h-4" />
                  )}
                </div>
                <div className="min-w-0">
                  <p className="text-xs font-semibold truncate text-white">
                    {browserActionToast.label}
                  </p>
                  <p className="text-[10px] text-neutral-300 truncate">
                    {browserActionToast.status === 'blocked'
                      ? 'Pop-up blocked: Tap to open'
                      : 'Opening in browser tab'}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  id="active-browser-action-open-btn"
                  onClick={() => {
                    triggerHaptic('tap');
                    // This click is a fresh user gesture, so it is the reliable
                    // fallback when automatic voice-triggered popups are blocked.
                    const requestedUrl = browserActionToast.url;
                    const openedWindow = window.open(requestedUrl, '_blank');
                    if (openedWindow) {
                      try {
                        openedWindow.opener = null;
                      } catch {
                        // Respect browser policies that disallow opener mutation.
                      }
                      setBrowserActionToast((prev) =>
                        prev?.url === requestedUrl
                          ? { ...prev, status: 'opened', timestamp: Date.now() }
                          : prev
                      );
                      setTimeout(() => {
                        setBrowserActionToast((prev) => (prev?.url === requestedUrl ? null : prev));
                      }, 8000);
                    } else {
                      setBrowserActionToast((prev) =>
                        prev?.url === requestedUrl
                          ? { ...prev, status: 'blocked', timestamp: Date.now() }
                          : prev
                      );
                    }
                  }}
                  className="px-3 py-1.5 rounded-xl bg-white text-black hover:bg-neutral-200 text-xs font-bold flex items-center gap-1 cursor-pointer transition-all active:scale-95 shadow-sm"
                >
                  <span>Open</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
                <button
                  onClick={() => setBrowserActionToast(null)}
                  className="p-1 rounded-lg text-neutral-400 hover:text-white transition-colors"
                  title="Dismiss"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* Clean Subtitle & Status Text - Overlayed below Orb without disturbing exact vertical centering */}
        </div>

        {/* Direct, minimalist conversation control. All advanced tools are
            integrated in the header or adaptive Workspace, not six busy tabs. */}
        <footer className="rodex-quiet-dock">
          {isLiveConversation && (
            <button type="button" id="hangup-call-btn" className="rodex-live-stop"
              onClick={endLiveCall}><PhoneOff size={16}/> End call</button>
          )}
          <form className="rodex-command-bar" onSubmit={(event) => {
            event.preventDefault();
            const command = quickPrompt.trim();
            if (!command) return;
            handleSendMessage(command);
            setIsChatOpen(true);
            setQuickPrompt('');
          }}>
            <button type="button" className="rodex-command-btn" aria-label="Open RODEX tools"
              onClick={() => { triggerHaptic('tap'); setIsMoreMenuOpen(true); }}>
              <Plus size={21} aria-hidden="true"/>
            </button>
            <input type="text" autoComplete="off"
              value={quickPrompt} onChange={event => setQuickPrompt(event.target.value)}
              placeholder="Talk or type to RODEX..." aria-label="Ask RODEX"/>
            {quickPrompt.trim() ? (
              <button type="submit" className="rodex-command-btn" aria-label="Send message">
                <ArrowUp size={20} aria-hidden="true"/>
              </button>
            ) : (
              <button type="button" className="rodex-command-btn" id="rodex-direct-voice-btn"
                aria-label={isLiveConversation ? 'End voice conversation' : 'Start voice conversation'}
                title={isLiveConversation ? 'End call' : 'Talk to RODEX'}
                onClick={() => { triggerHaptic('tap'); if (isLiveConversation) endLiveCall(); else startLiveCall(); }}>
                {isLiveConversation ? <PhoneOff size={20}/> : <Mic size={20}/>}
              </button>
            )}
            <button type="button" className="rodex-command-btn rodex-command-chat-btn"
              aria-label="Open conversation history" onClick={() => { triggerHaptic('tap'); setIsChatOpen(true); }}>
              <MessageSquare size={20} aria-hidden="true"/>
            </button>
          </form>
          <RodexSpeechWave state={state} audioLevel={audioLevel}/>
        </footer>

        {/* Keep the approved humanoid present as a compact, controllable
            companion while existing tool/modal workspaces cover the page.
            Chat remains unobstructed and has its own close navigation. */}
        {/* Tools can open directly from Home without opening Workspace first.
            Keep the character available on tools, but never over Chat. */}
        <RODEXFloatingCompanion
          active={!isChatOpen && (
            activeMode !== 'home' || isMediaStudioOpen || isGmailOpen ||
            isScheduleOpen || isMemoryOpen || isDoctorOpen || isCapabilityOpen ||
            isWebVerifyOpen || isSpotifyOpen || isMediaHubOpen || isSecurityOpen ||
            isUpdateOpen || isMoreMenuOpen || isSettingsOpen
          )}
          state={state}
          taskState={activeTask?.state}
          audioLevel={audioLevel}
          onSpeak={handleOrbClick}
          onExpand={returnToHome}
        />

        {/* Slide-up Chat History Sheet */}
        <ChatSheet
          isOpen={isChatOpen}
          onClose={() => setIsChatOpen(false)}
          activeSession={activeSession}
          allSessions={allSessions}
          onSelectSession={handleSelectSession}
          onNewSession={handleNewSession}
          onDeleteSession={handleDeleteSession}
          messages={messages}
          onSendMessage={(text) => handleSendMessage(text)}
          onReplayAudio={(text) => speakResponse(text)}
          onClearHistory={() => setMessages([])}
          assistantState={state}
          isLiveConversation={isLiveConversation}
          onConfirmAction={handleConfirmAction}
          onToggleLiveCall={() => {
            if (isLiveConversation) {
              endLiveCall();
            } else {
              startLiveCall();
            }
          }}
        />

        {/* Settings Modal */}
        <SettingsModal
          isOpen={isSettingsOpen}
          onClose={() => setIsSettingsOpen(false)}
          voiceSettings={voiceSettings}
          onUpdateVoiceSettings={setVoiceSettings}
          themeAccent={themeAccent}
          onUpdateTheme={handleUpdateTheme}
          onRequestMicPermission={requestMicPermission}
          micPermissionGranted={micPermissionGranted}
          onOpenUserProfile={() => {
            setIsSettingsOpen(false);
            if (currentUser) setIsUserProfileOpen(true);
            else { setAuthModalTab('signin'); setIsAuthModalOpen(true); }
          }}
          onOpenVoiceProfile={() => setIsVoiceProfileOpen(true)}
          onOpenSpotify={() => setIsSpotifyOpen(true)}
          onOpenWebVerify={() => setIsWebVerifyOpen(true)}
          onOpenMemory={() => setIsMemoryOpen(true)}
          onOpenGmail={() => setIsGmailOpen(true)}
          onSelectMode={(mode) => {
            if (mode === 'home') {
              setActiveMode('home');
              setIsChatOpen(false);
            } else {
              setActiveMode(mode);
            }
          }}
        />

        {/* More Menu Drawer */}
        <MoreMenu
          isOpen={isMoreMenuOpen}
          onClose={() => setIsMoreMenuOpen(false)}
          currentUser={currentUser}
          onOpenChat={() => setIsChatOpen(true)}
          onOpenImage={() => {
            setMediaStudioTab('image');
            setIsMediaStudioOpen(true);
          }}
          onOpenSchedule={() => setIsScheduleOpen(true)}
          onOpenPlugins={() => setIsCapabilityOpen(true)}
          onOpenUserProfile={() => setIsUserProfileOpen(true)}
          onOpenAuthModal={() => {
            setAuthModalTab('signin');
            setIsAuthModalOpen(true);
          }}
          onOpenSecurity={() => setIsSecurityOpen(true)}
          onOpenGmail={() => setIsGmailOpen(true)}
          onOpenDoctor={() => setIsDoctorOpen(true)}
          onOpenUpdate={() => setIsUpdateOpen(true)}
          onOpenMemory={() => setIsMemoryOpen(true)}
          onOpenMediaStudio={() => {
            setMediaStudioTab('video');
            setIsMediaStudioOpen(true);
          }}
          onOpenMediaHub={() => setIsMediaHubOpen(true)}
          onOpenSettings={() => setIsSettingsOpen(true)}
        />

        {/* Voice Profile & Biometrics Modal */}
        <VoiceProfileModal
          isOpen={isVoiceProfileOpen}
          onClose={() => setIsVoiceProfileOpen(false)}
          profile={voiceProfile}
          onRecalibrate={() => {
            setVoiceProfile((prev) => ({
              ...prev,
              confidence: 99.8,
              voiceprintStatus: 'calibrated',
            }));
            speakResponse('Voice profile recalibrated successfully.');
          }}
          onTestWakeWord={() => {
            setIsVoiceProfileOpen(false);
            handleSendMessage('Hey RODEX');
          }}
        />

        {/* Action Modes Modal (Image, File, Code, More / Flutter APK, Web Intel) */}
        <ModesModal
          mode={activeMode}
          onClose={() => setActiveMode('home')}
          onSubmitPrompt={(text, image) => handleSendMessage(text, image)}
          currentSources={lastSources}
          onOpenSpotify={() => setIsSpotifyOpen(true)}
          onOpenMemory={() => setIsMemoryOpen(true)}
          onOpenCapabilities={() => setIsCapabilityOpen(true)}
          onOpenMediaStudio={(tab) => {
            setMediaStudioTab(tab);
            setIsMediaStudioOpen(true);
          }}
          onOpenSecurity={() => setIsSecurityOpen(true)}
          onOpenGmail={() => setIsGmailOpen(true)}
          onOpenDoctor={() => setIsDoctorOpen(true)}
          onOpenUpdate={() => setIsUpdateOpen(true)}
          onOpenUserProfile={() => setIsUserProfileOpen(true)}
          onOpenSettings={() => setIsSettingsOpen(true)}
          onOpenVoiceProfile={() => setIsVoiceProfileOpen(true)}
        />

        {/* Schedule Hub Modal */}
        <ScheduleModal
          isOpen={isScheduleOpen}
          onClose={() => setIsScheduleOpen(false)}
          onAddReminder={(title, timeStr) => {
            handleSendMessage(`Remind me to ${title} at ${timeStr}`);
          }}
        />


        {/* World Wide Web Verification & Real-Time API Monitor Modal */}
        <WebVerificationModal
          isOpen={isWebVerifyOpen}
          onClose={() => setIsWebVerifyOpen(false)}
          onAskRodex={(prompt) => {
            setIsWebVerifyOpen(false);
            handleSendMessage(prompt);
          }}
        />

        {/* Spotify PC Access & Player Modal */}
        <SpotifyPlayerModal
          isOpen={isSpotifyOpen}
          onClose={() => setIsSpotifyOpen(false)}
          onSpeakStatus={(text) => speakResponse(text)}
        />

        {/* Web Music & Video Intelligence Hub Modal */}
        <WebMediaHubModal
          isOpen={isMediaHubOpen}
          onClose={() => setIsMediaHubOpen(false)}
          onSpeakStatus={(text) => speakResponse(text)}
        />

        {/* RODEX Security Center Modal */}
        <SecurityCenterModal
          isOpen={isSecurityOpen}
          onClose={() => setIsSecurityOpen(false)}
          onSpeakStatus={(text) => speakResponse(text)}
        />

        {/* RODEX Autonomous Update & Intelligence Center Modal */}
        <UpdateCenterModal
          isOpen={isUpdateOpen}
          onClose={() => setIsUpdateOpen(false)}
          onSpeakStatus={(text) => speakResponse(text)}
        />

        {/* Multi-User Account Profile Modal */}
        <UserProfileModal
          isOpen={isUserProfileOpen}
          onClose={() => setIsUserProfileOpen(false)}
          currentUser={currentUser}
          onUserUpdated={(user) => {
            setCurrentUser(user);
          }}
          onOpenAuthModal={(tab) => {
            setAuthModalTab(tab);
            setIsAuthModalOpen(true);
          }}
          onLogout={() => {
            globalAuthClient.logout();
            setCurrentUser(null);
            speakResponse('You have signed out of your account.');
          }}
        />

        {/* Authentication & Registration Modal */}
        <AuthModal
          isOpen={isAuthModalOpen}
          onClose={() => setIsAuthModalOpen(false)}
          initialTab={authModalTab}
          onSuccess={(user) => {
            setCurrentUser(user);
            speakResponse(`Welcome, ${user.displayName}. Your account is authenticated.`);
          }}
        />

        {/* Long-Term Memory & User Personalization Modal */}
        <MemoryPersonalizationModal
          isOpen={isMemoryOpen}
          onClose={() => setIsMemoryOpen(false)}
          onNotification={(msg) => speakResponse(msg)}
        />

        {/* RODEX Capability Hub & Multi-Domain System Modal */}
        <CapabilityHubModal
          isOpen={isCapabilityOpen}
          onClose={() => setIsCapabilityOpen(false)}
          onExecutePrompt={(prompt) => handleSendMessage(prompt)}
        />

        {/* RODEX Multimodal Studio (Veo 3 Video, Image Edit, Maps & Search Grounding, Firebase Gallery) */}
        <MediaStudioModal
          isOpen={isMediaStudioOpen}
          onClose={() => setIsMediaStudioOpen(false)}
          initialTab={mediaStudioTab}
        />

        {/* RODEX Doctor Master Self-Diagnostic & Reliability Dashboard Modal */}
        <RodexDoctorModal
          isOpen={isDoctorOpen}
          onClose={() => setIsDoctorOpen(false)}
        />

        {/* RODEX Official Gmail & Email Integration Hub Modal */}
        <GmailHubModal
          isOpen={isGmailOpen}
          onClose={() => setIsGmailOpen(false)}
          onNotification={(text) => {
            rodexSynth.speak(text);
          }}
        />

        {/* Developer diagnostics are opt-in and never part of the natural character UI. */}
        {typeof window !== 'undefined' && new URLSearchParams(window.location.search).has('diagnostics') && (
          <VoiceDiagnosticPanel
          assistantState={state}
          lastTranscript={transcript}
          wakeMatched={diagWakeMatched}
          capturedCommand={capturedCommand}
          aiRequestState={aiRequestState}
          aiResponseState={aiResponseState}
          ttsState={ttsState}
          />
        )}
      </main>
    </AndroidFrame>
  );
}
